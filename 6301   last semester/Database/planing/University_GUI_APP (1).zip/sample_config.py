# Update these values for your local mysql instance
# Make sure the file is saved as config.py

config = {
    'username': 'root',
    'password': 'password',
    'database': 'university',
    'host': 'localhost',
    'port': 3306
}